# rust_kalkulator
Prosty kalkulator napisany w języku rust
